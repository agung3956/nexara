import React from "react";

export default function App() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "#0f172a",
      color: "white",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "Arial"
    }}>
      <div style={{
        background: "rgba(255,255,255,0.08)",
        padding: "40px",
        borderRadius: "24px",
        width: "700px"
      }}>
        <h1 style={{fontSize: "42px"}}>Nexara InvoiceFlow</h1>
        <p>Aplikasi Invoice dan Kwitansi Otomatis</p>

        <div style={{
          marginTop: "30px",
          background: "white",
          color: "#111827",
          padding: "24px",
          borderRadius: "20px"
        }}>
          <h2>Invoice Preview</h2>
          <p>Client: PT Bangka Digital Kreatif</p>
          <p>Project: Landing Page Premium</p>
          <p>Total: Rp7.000.000</p>

          <button style={{
            marginTop: "20px",
            background: "#111827",
            color: "white",
            border: "none",
            padding: "14px 22px",
            borderRadius: "12px",
            cursor: "pointer"
          }}>
            Export PDF
          </button>
        </div>
      </div>
    </div>
  );
}
